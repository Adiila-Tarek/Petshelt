package com.example.graduation_projectt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
