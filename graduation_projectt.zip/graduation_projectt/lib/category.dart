class Category{
  late String user_name;
  late String imagepath;
  late String content;

  Category(this.user_name,this.imagepath,this.content);


}