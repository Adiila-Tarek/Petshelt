import 'package:flutter/material.dart';
import 'package:graduation_projectt/ui/adoption.dart';
import 'package:graduation_projectt/ui/home/HomeScreen.dart';
import 'package:graduation_projectt/ui/home/all-in-one.dart';
import 'package:graduation_projectt/ui/home/commitment.dart';
import 'package:graduation_projectt/ui/home/homeless.dart';
import 'package:graduation_projectt/ui/home/knowing.dart';
import 'package:graduation_projectt/ui/home/menue.dart';
import 'package:graduation_projectt/ui/home/saved.dart';
import 'package:graduation_projectt/ui/home/shop.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      routes: {
        HomeScreen.routeName:(buildContext)=>HomeScreen(),
        Adoption.routeName:(buildContext)=>Adoption(),
        Homeless.routeName:(buildContext)=>Homeless(),
        Knowing.routeName:(buildContext)=>Knowing(),
        Commitment.routeName:(buildContext)=>Commitment(),
        Shopping.routeName:(buildContext)=>Shopping(),
        All.routeName:(buildContext)=>All(),
        Menue.routeName:(buildContext)=>Menue(),
        Saved.routeName:(buildContext)=>Saved(),






      },
    initialRoute: HomeScreen.routeName,
    );
  }
}
